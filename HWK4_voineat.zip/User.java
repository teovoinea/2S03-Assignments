/*
* Name: Nick Morrison, Roberto Temelkovski, Teodor Voinea
* MacID: morrin2, temelkr, voineat
* Student Number: 1426613, 1418731, 1409586
* Description: File containing the User class
*/

//User class scaffolding
public class User{
	//private string to store the current user's username
	private String username;
 
 	//setter for the private variable username
	public void setUsername(String name){
		//set username
		username = name;
	}
	//getter for the private variable username
	public String getUsername(){
		//return username
		return username;
	}
	//User class constructor
	public User(){
	}
}